/* eslint-disable func-names, space-before-function-paren, wrap-iife */

(function() {
  this.ProjectShow = (function() {
    function ProjectShow() {}

    return ProjectShow;
  })();
}).call(this);

// I kept class for future
