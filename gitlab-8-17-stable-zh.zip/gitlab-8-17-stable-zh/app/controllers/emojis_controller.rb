class EmojisController < ApplicationController
  layout false

  def index
  end
end
